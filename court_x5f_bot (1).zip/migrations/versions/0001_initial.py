
"""initial"""
from alembic import op
import sqlalchemy as sa
revision = '0001_initial'
down_revision = None
branch_labels = None
depends_on = None

def upgrade():
    op.create_table('groups',
        sa.Column('id', sa.Integer(), primary_key=True),
        sa.Column('telegram_group_id', sa.BigInteger(), unique=True),
        sa.Column('title', sa.String(500)),
        sa.Column('is_authorized', sa.Boolean(), default=False),
        sa.Column('created_at', sa.DateTime(), default=sa.func.now())
    )
    op.create_table('users',
        sa.Column('id', sa.Integer(), primary_key=True),
        sa.Column('telegram_id', sa.BigInteger(), unique=True),
        sa.Column('username', sa.String(255)),
        sa.Column('first_name', sa.String(255)),
        sa.Column('last_name', sa.String(255)),
        sa.Column('role', sa.String(20), default='EMPLOYEE'),
        sa.Column('is_active', sa.Boolean(), default=True),
        sa.Column('group_id', sa.Integer(), sa.ForeignKey('groups.id'), nullable=True),
        sa.Column('created_at', sa.DateTime(), default=sa.func.now()),
        sa.Column('last_active', sa.DateTime(), default=sa.func.now())
    )
    op.create_table('materials',
        sa.Column('id', sa.Integer(), primary_key=True),
        sa.Column('title', sa.String(500), nullable=False),
        sa.Column('file_name', sa.String(500)),
        sa.Column('file_id', sa.String(500)),
        sa.Column('category', sa.String(200), default='general'),
        sa.Column('description', sa.Text()),
        sa.Column('status', sa.String(20), default='UPLOADED'),
        sa.Column('error_message', sa.Text()),
        sa.Column('extracted_text', sa.Text()),
        sa.Column('uploader_id', sa.BigInteger()),
        sa.Column('created_at', sa.DateTime(), default=sa.func.now()),
        sa.Column('chunks_count', sa.Integer(), default=0)
    )
    op.create_table('material_chunks',
        sa.Column('id', sa.Integer(), primary_key=True),
        sa.Column('material_id', sa.Integer(), sa.ForeignKey('materials.id', ondelete='CASCADE')),
        sa.Column('chunk_index', sa.Integer()),
        sa.Column('page_number', sa.Integer(), nullable=True),
        sa.Column('text', sa.Text(), nullable=False),
        sa.Column('embedding', sa.JSON(), nullable=True),
        sa.Column('created_at', sa.DateTime(), default=sa.func.now())
    )
    op.create_table('news',
        sa.Column('id', sa.Integer(), primary_key=True),
        sa.Column('title', sa.String(500), nullable=False),
        sa.Column('body', sa.Text(), nullable=False),
        sa.Column('category', sa.String(200), default='general'),
        sa.Column('source', sa.String(500)),
        sa.Column('is_active', sa.Boolean(), default=True),
        sa.Column('created_at', sa.DateTime(), default=sa.func.now())
    )
    op.create_table('questions',
        sa.Column('id', sa.Integer(), primary_key=True),
        sa.Column('question_text', sa.Text(), nullable=False),
        sa.Column('option_a', sa.Text(), nullable=False),
        sa.Column('option_b', sa.Text(), nullable=False),
        sa.Column('option_c', sa.Text(), nullable=False),
        sa.Column('option_d', sa.Text(), nullable=False),
        sa.Column('correct_option', sa.String(1), nullable=False),
        sa.Column('explanation', sa.Text()),
        sa.Column('topic', sa.String(300)),
        sa.Column('difficulty', sa.String(20), default='medium'),
        sa.Column('source_document_id', sa.Integer(), sa.ForeignKey('materials.id'), nullable=True),
        sa.Column('source_chunk_id', sa.Integer(), sa.ForeignKey('material_chunks.id'), nullable=True),
        sa.Column('source_reference', sa.String(500)),
        sa.Column('source_excerpt', sa.Text()),
        sa.Column('is_approved', sa.Boolean(), default=True),
        sa.Column('created_at', sa.DateTime(), default=sa.func.now()),
        sa.Column('ai_metadata', sa.JSON(), nullable=True)
    )
    op.create_table('tests',
        sa.Column('id', sa.Integer(), primary_key=True),
        sa.Column('title', sa.String(500), nullable=False),
        sa.Column('description', sa.Text()),
        sa.Column('num_questions', sa.Integer(), default=20),
        sa.Column('num_options', sa.Integer(), default=4),
        sa.Column('difficulty', sa.String(20), default='mixed'),
        sa.Column('news_percentage', sa.Integer(), default=0),
        sa.Column('duration_hours', sa.Integer(), default=24),
        sa.Column('randomize_questions', sa.Boolean(), default=True),
        sa.Column('randomize_answers', sa.Boolean(), default=True),
        sa.Column('show_correct_after', sa.Boolean(), default=False),
        sa.Column('allow_retake', sa.Boolean(), default=False),
        sa.Column('passing_percentage', sa.Integer(), default=70),
        sa.Column('status', sa.String(20), default='DRAFT'),
        sa.Column('start_at', sa.DateTime(), nullable=True),
        sa.Column('deadline_at', sa.DateTime(), nullable=True),
        sa.Column('created_by', sa.BigInteger()),
        sa.Column('created_at', sa.DateTime(), default=sa.func.now())
    )
    op.create_table('test_questions',
        sa.Column('id', sa.Integer(), primary_key=True),
        sa.Column('test_id', sa.Integer(), sa.ForeignKey('tests.id', ondelete='CASCADE')),
        sa.Column('question_id', sa.Integer(), sa.ForeignKey('questions.id', ondelete='CASCADE')),
        sa.Column('order_index', sa.Integer()),
        sa.Column('snapshot', sa.JSON(), nullable=False)
    )
    op.create_table('test_attempts',
        sa.Column('id', sa.Integer(), primary_key=True),
        sa.Column('test_id', sa.Integer(), sa.ForeignKey('tests.id')),
        sa.Column('user_id', sa.Integer(), sa.ForeignKey('users.id')),
        sa.Column('telegram_id', sa.BigInteger()),
        sa.Column('status', sa.String(20), default='NOT_STARTED'),
        sa.Column('started_at', sa.DateTime(), nullable=True),
        sa.Column('completed_at', sa.DateTime(), nullable=True),
        sa.Column('deadline_at', sa.DateTime(), nullable=True),
        sa.Column('total_questions', sa.Integer(), default=0),
        sa.Column('answered_questions', sa.Integer(), default=0),
        sa.Column('correct_answers', sa.Integer(), default=0),
        sa.Column('incorrect_answers', sa.Integer(), default=0),
        sa.Column('score', sa.Float(), default=0.0),
        sa.Column('percentage', sa.Float(), default=0.0),
        sa.Column('duration_seconds', sa.Integer(), default=0)
    )
    op.create_table('user_answers',
        sa.Column('id', sa.Integer(), primary_key=True),
        sa.Column('attempt_id', sa.Integer(), sa.ForeignKey('test_attempts.id', ondelete='CASCADE')),
        sa.Column('test_question_id', sa.Integer(), sa.ForeignKey('test_questions.id')),
        sa.Column('question_id', sa.Integer(), sa.ForeignKey('questions.id')),
        sa.Column('selected_option', sa.String(1), nullable=True),
        sa.Column('actual_selected', sa.String(1), nullable=True),
        sa.Column('is_correct', sa.Boolean(), default=False),
        sa.Column('answered_at', sa.DateTime(), default=sa.func.now())
    )

def downgrade():
    op.drop_table('user_answers')
    op.drop_table('test_attempts')
    op.drop_table('test_questions')
    op.drop_table('tests')
    op.drop_table('questions')
    op.drop_table('news')
    op.drop_table('material_chunks')
    op.drop_table('materials')
    op.drop_table('users')
    op.drop_table('groups')
