
# Sud Xodimlari Uchun Telegram O'qitish Bot

Professional, production-ready Telegram bot for training and testing court employees.

## Xususiyatlar
- 👥 Xodimlarni Telegram ID bo'yicha ro'yxatga olish
- 📚 Materiallar (PDF, DOCX, TXT, MD) yuklash va avtomatik qayta ishlash
- 🧠 RAG pipeline: chunking -> embeddings -> vector search -> Groq LLM
- 🤖 Faqat yuklangan manbalardan savol generatsiyasi (source-grounded)
- 📝 Test yaratish, randomizatsiya, 24 soat deadline
- 📊 Qatnashuv statistikasi: qatnashgan / qatnashmagan / jarayonda / yakunlagan / muddati o'tgan
- ❌ Noto'g'ri javoblar tahlili, zaif mavzular
- 🏆 Reyting (kunlik/haftalik/oylik/umumiy)
- 📈 Excel hisobot eksport
- 👥 Guruhlarni ro'yxatga olish va test e'lonlari

## Texnologiyalar
Python 3.12, aiogram 3.x, PostgreSQL + pgvector, SQLAlchemy 2.x, Alembic, Groq API, sentence-transformers, Docker, Railway

## O'rnatish (Local)

1. Clone:
```bash
git clone <repo>
cd court_bot
```

2. Venv:
```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

3. .env yaratish:
```bash
cp .env.example .env
# .env ni to'ldiring
```

4. PostgreSQL (docker-compose):
```bash
docker-compose up -d db
```

5. Migratsiya:
```bash
alembic upgrade head
```

6. Botni ishga tushirish:
```bash
python -m app.main
```

## Environment Variables
```
BOT_TOKEN=
GROQ_API_KEY=
DATABASE_URL=postgresql+asyncpg://postgres:postgres@localhost:5432/court_bot
ADMIN_TELEGRAM_IDS=123456789
TIMEZONE=Asia/Tashkent
```

## Telegram Bot Sozlash
1. @BotFather -> /newbot -> token oling
2. Tokenni .env ga qo'ying
3. Botni ishga tushiring
4. /start bosing
5. ADMIN_TELEGRAM_IDS ga o'z Telegram ID ni qo'ying ( @userinfobot orqali bilib oling)
6. /admin -> Admin panel

## Railway Deploy
1. GitHub ga push:
```bash
git init
git add .
git commit -m "initial"
git remote add origin <github_url>
git push -u origin main
```

2. Railway:
- New Project -> Deploy from GitHub
- Variables qo'shish: BOT_TOKEN, GROQ_API_KEY, ADMIN_TELEGRAM_IDS, TIMEZONE
- Railway avtomatik DATABASE_URL beradi (PostgreSQL plugin qo'shing)
- Dockerfile orqali deploy bo'ladi
- Start command: `alembic upgrade head && python -m app.main`

3. Agar Railway Postgres pgvector ni qo'llab-quvvatlamasa, fallback embedding JSON da ishlaydi (kodda bor).

## Foydalanish

### Admin:
- /admin -> Materiallar -> Yuklash (PDF yuboring)
- Material READY bo'lgach -> Testlar -> Yangi test -> nom, savollar soni, muddat, yangilik foizi
- Test yaratilgach -> Ko'rish -> Faollashtirish
- Xodimlar testni /tests orqali ko'radi
- Statistika -> Ishtirokchilar, Reyting, Hisobot

### Xodim:
- /start -> avtomatik ro'yxatga olinadi
- /tests -> testlar ro'yxati -> Testni boshlash
- Har bir savolga javob -> Keyingi savol
- Yakunda natija: to'g'ri/noto'g'ri/foiz/vaqt

## Test Lifecycle
DRAFT -> READY -> ACTIVE -> EXPIRED/CLOSED
Draft testlar xodimlarga ko'rinmaydi.

## RAG
Document -> extract (PyPDF2, python-docx) -> clean -> chunk (800 chars, 100 overlap) -> embeddings (sentence-transformers) -> pgvector/JSON -> retrieve top-k -> Groq LLM -> Pydantic validation -> Question DB

## Xavfsizlik
- Admin ID env dan
- Tokenlar loglanmaydi
- Fayl hajmi cheklangan (20 MB default)
- SQLAlchemy orqali SQL injection himoyasi
- Server-side deadline tekshiruvi

## Loyiha Tuzilishi
```
app/
  config/
  database/models.py
  handlers/
  keyboards/
  middlewares/
  services/
  ai/
  rag/
  localization/
  utils/
migrations/
tests/
```

## Testlar
```bash
pytest tests/
```

## Troubleshooting
- Bot javob bermasa: BOT_TOKEN tekshiring, polling ishlayotganini logdan ko'ring
- Material FAILED: fayl matni yo'q yoki Groq API kaliti xato
- DB xatolik: DATABASE_URL ni tekshiring, alembic upgrade head qayta ishga tushiring
- Groq error: GROQ_API_KEY to'g'ri ekanini va limit tugamaganini tekshiring
