
import pytest
from app.schemas.question import GeneratedQuestion
from app.ai.validator import validate_question
from app.rag.chunker import chunk_text
from app.rag.embeddings import embed_texts, cosine_similarity

def test_question_validation():
    data = {
        "question": "Sud majlisi qachon boshlanadi?",
        "options": {"A": "9:00 da", "B": "10:00 da", "C": "11:00 da", "D": "12:00 da"},
        "correct_answer": "A",
        "explanation": "Manbada 9:00 da boshlanishi ko'rsatilgan",
        "topic": "Sud jarayoni",
        "difficulty": "easy",
        "source_reference": "Doc 1, page 5",
        "source_excerpt": "Sud majlisi soat 9:00 da boshlanadi"
    }
    valid, q = validate_question(data)
    assert valid

def test_duplicate_options():
    data = {
        "question": "Test question with enough length?",
        "options": {"A": "Same", "B": "Same", "C": "Different", "D": "Other"},
        "correct_answer": "A",
        "explanation": "Explanation",
        "topic": "test",
        "difficulty": "easy",
        "source_reference": "ref",
        "source_excerpt": "excerpt text long enough for validation"
    }
    valid, _ = validate_question(data)
    assert not valid

def test_chunker():
    text = "Bu birinchi gap. Bu ikkinchi gap. " * 100
    chunks = chunk_text(text, 200, 20)
    assert len(chunks) > 1
    assert all(len(c) <= 250 for c in chunks)

def test_embeddings():
    embs = embed_texts(["salom dunyo", "salom dunyo"])
    assert len(embs) == 2
    sim = cosine_similarity(embs[0], embs[1])
    assert sim > 0.9

def test_randomized_answer_mapping():
    # simulate randomization logic
    options = {"A": "opt1", "B": "opt2", "C": "opt3", "D": "opt4"}
    correct = "B"
    correct_val = options[correct]
    import random
    vals = list(options.values())
    random.seed(42)
    random.shuffle(vals)
    new_opts = {}
    new_correct = None
    for i, v in enumerate(vals):
        k = ["A","B","C","D"][i]
        new_opts[k]=v
        if v==correct_val:
            new_correct=k
    assert new_opts[new_correct]==correct_val
