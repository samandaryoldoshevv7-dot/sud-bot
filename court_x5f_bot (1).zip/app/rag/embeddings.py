
from typing import List
try:
    _log=False
except:
    pass

try:
    from sentence_transformers import SentenceTransformer
    _model = None
    def get_model():
        global _model
        if _model is None:
            from app.config.settings import settings
            _model = SentenceTransformer(settings.EMBEDDING_MODEL)
        return _model
    def embed_texts(texts: List[str]) -> List[List[float]]:
        model = get_model()
        embs = model.encode(texts, normalize_embeddings=True)
        return [e.tolist() for e in embs]
except Exception as e:
    def embed_texts(texts: List[str]) -> List[List[float]]:
        import hashlib, random
        res=[]
        for t in texts:
            h=int(hashlib.md5(t.encode()).hexdigest()[:8],16)
            random.seed(h)
            vec=[random.uniform(-1,1) for _ in range(384)]
            norm=sum(x*x for x in vec)**0.5 or 1
            res.append([x/norm for x in vec])
        return res

def cosine_similarity(a,b):
    return sum(x*y for x,y in zip(a,b))
