
import re
from typing import List

def clean_text(text: str) -> str:
    text = text.replace('\r', '\n')
    text = re.sub(r'\n{3,}', '\n\n', text)
    return text.strip()

def chunk_text(text: str, chunk_size: int = 800, overlap: int = 100) -> List[str]:
    text = clean_text(text)
    if len(text) <= chunk_size:
        return [text]
    chunks = []
    start = 0
    while start < len(text):
        end = start + chunk_size
        # try to break at sentence
        if end < len(text):
            # find last dot
            last_dot = text.rfind('.', start, end)
            if last_dot != -1 and last_dot > start + chunk_size*0.5:
                end = last_dot+1
        chunks.append(text[start:end].strip())
        start = end - overlap
    return [c for c in chunks if len(c.strip()) > 50]
