
from app.schemas.question import GeneratedQuestion
import logging
logger=logging.getLogger(__name__)

def validate_question(data: dict):
    try:
        q=GeneratedQuestion(**data)
        if len(q.explanation)<10:
            return False, "explanation too short"
        if q.source_excerpt and len(q.source_excerpt)<10:
            return False, "source excerpt too short"
        return True,q
    except Exception as e:
        logger.error(f"validation failed {e}")
        return False,str(e)
