
from groq import AsyncGroq
from app.config.settings import settings
from app.ai.prompts import QUESTION_GENERATION_PROMPT
import json, asyncio, logging
logger=logging.getLogger(__name__)

class AIProvider:
    def __init__(self):
        self.client=AsyncGroq(api_key=settings.GROQ_API_KEY)
        self.model="llama-3.3-70b-versatile"
    async def generate_question(self, context, topic="general", difficulty="medium", retries=3):
        prompt=QUESTION_GENERATION_PROMPT.format(context=context[:8000], topic=topic, difficulty=difficulty)
        for attempt in range(retries):
            try:
                resp=await self.client.chat.completions.create(
                    model=self.model,
                    messages=[{"role":"user","content":prompt}],
                    temperature=0.3,
                    max_tokens=1500,
                    response_format={"type":"json_object"}
                )
                text=resp.choices[0].message.content
                data=json.loads(text)
                if "error" in data:
                    return None
                return data
            except Exception as e:
                logger.error(f"groq error {e} attempt {attempt}")
                await asyncio.sleep(1)
        return None
    async def generate_questions_batch(self, chunks, num_questions, topic="general"):
        results=[]
        for chunk in chunks[:num_questions*2]:
            if len(results)>=num_questions:
                break
            ctx=chunk.text if hasattr(chunk,'text') else str(chunk)
            data=await self.generate_question(ctx, topic=topic)
            if data:
                data["_source_chunk_id"]=getattr(chunk,'id',None)
                data["_source_excerpt_raw"]=ctx[:500]
                results.append(data)
        return results
provider=AIProvider()
