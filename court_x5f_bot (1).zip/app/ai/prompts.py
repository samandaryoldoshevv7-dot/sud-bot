
QUESTION_GENERATION_PROMPT = """
Siz sud hujjatlari asosida test savollari yaratuvchi yordamchisiz.

QAT'IY QOIDALAR:
- Faqat quyida berilgan MANBA MATNI dan foydalaning. Tashqaridan fakt o'ylab topmang.
- Agar manba yetarli bo'lmasa, savol yaratmang va {"error": "insufficient_source"} qaytaring.
- Har bir savol faqat BIR to'g'ri javobga ega bo'lsin.
- Barcha variantlar mantiqli va chalg'ituvchi bo'lsin, dublikat bo'lmasin.
- O'zbek tilida yozing.

MANBA MATNI:
{context}

Mavzu: {topic}
Qiyinlik: {difficulty}

Quyidagi JSON formatida JAVOB BERING, boshqa matn yo'q:
{
  "question": "...",
  "options": {"A": "...", "B": "...", "C": "...", "D": "..."},
  "correct_answer": "C",
  "explanation": "Manbada ... deb ko'rsatilgan, shuning uchun to'g'ri javob C",
  "topic": "Mavzu nomi",
  "difficulty": "medium",
  "source_reference": "Hujjat nomi, sahifa",
  "source_excerpt": "Manbadan qisqa iqtibos (max 200 belgi)"
}
"""

VALIDATION_PROMPT = """
Savolni tekshir:
Savol: {question}
Variantlar: {options}
To'g'ri: {correct}
Manba: {source_excerpt}
Manba savolni qo'llab-quvvatlaydimi? Ha/Yo'q va sababini JSON da qaytar:
{"valid": true/false, "reason": "..."}
"""
