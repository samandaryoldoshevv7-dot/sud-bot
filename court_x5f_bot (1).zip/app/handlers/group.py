
from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message
from sqlalchemy import select
from app.database.models import Group

router = Router()

@router.message(Command("register_group"))
async def register_group(message: Message, session, is_admin: bool):
    if not is_admin:
        await message.answer("⛔ Faqat adminlar guruhni ro'yxatga olishi mumkin")
        return
    chat = message.chat
    if chat.type not in ["group","supergroup"]:
        await message.answer("Bu buyruq faqat guruhlarda ishlaydi")
        return
    stmt = select(Group).where(Group.telegram_group_id==chat.id)
    res = await session.execute(stmt)
    grp = res.scalar_one_or_none()
    if not grp:
        grp = Group(telegram_group_id=chat.id, title=chat.title, is_authorized=True)
        session.add(grp)
        await session.commit()
    else:
        grp.is_authorized=True
        await session.commit()
    await message.answer(f"✅ Guruh ro'yxatga olindi: {chat.title}")
