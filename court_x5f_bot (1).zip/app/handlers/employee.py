
from aiogram import Router, F
from aiogram.filters import Command
from aiogram.types import Message, CallbackQuery
from sqlalchemy import select
from app.database.models import Test, TestStatus, TestAttempt, AttemptStatus, TestQuestion, UserAnswer
from app.services.test_service import start_attempt, get_test_questions_for_attempt
from app.keyboards.employee import start_test_kb, answer_kb, next_question_kb
from app.localization.texts import t
from app.utils.time import utcnow, to_tashkent, format_duration
import random, json

router = Router()

@router.message(Command("tests"))
async def list_tests(message: Message, session, db_user):
    stmt = select(Test).where(Test.status==TestStatus.ACTIVE.value).order_by(Test.id.desc())
    res = await session.execute(stmt)
    tests = res.scalars().all()
    if not tests:
        await message.answer(t.NO_TESTS)
        return
    for test in tests:
        deadline = to_tashkent(test.deadline_at)
        txt = f"📝 {test.title}\n❓ Savollar: {test.num_questions}\n⏰ Muddat: {deadline}\n\n{test.description or ''}"
        await message.answer(txt, reply_markup=start_test_kb(test.id))

@router.callback_query(F.data.startswith("start_test_"))
async def cb_start_test(call: CallbackQuery, session, db_user):
    test_id = int(call.data.split("_")[-1])
    test = await session.get(Test, test_id)
    if not test or test.status != TestStatus.ACTIVE.value:
        await call.answer("Test topilmadi yoki faol emas", show_alert=True)
        return
    attempt = await start_attempt(session, test_id, db_user.id, db_user.telegram_id)
    if not attempt:
        await call.answer("Siz bu testni allaqachon yakunladingiz (qayta topshirish ruxsat etilmagan)", show_alert=True)
        return
    # store current question index in attempt? Use simple: first question
    questions = await get_test_questions_for_attempt(session, test_id)
    if not questions:
        await call.answer("Savollar topilmadi", show_alert=True)
        return
    # randomize if needed
    if test.randomize_questions:
        random.shuffle(questions)
    # save order in attempt? For simplicity, we rely on order_index but shuffle display order via session cache? We'll store in state
    # For MVP: just show first question
    first = questions[0]
    snap = first.snapshot
    options = snap["options"]
    # randomize answers if needed, preserve mapping
    display_options = options.copy()
    correct = snap["correct_option"]
    if test.randomize_answers:
        keys = list(options.keys())
        values = list(options.values())
        # mapping original correct value
        correct_val = options[correct]
        random.shuffle(values)
        # rebuild A-D with shuffled values
        new_options = {}
        new_correct = None
        for i, val in enumerate(values):
            k = ["A","B","C","D"][i]
            new_options[k]=val
            if val==correct_val:
                new_correct=k
        display_options = new_options
        # store mapping in attempt? We'll need to save actual correct mapping in UserAnswer actual_selected
        # For simplicity store correct mapping in cache via attempt metadata - we use snapshot override
        # We'll store new_correct in memory via callback? Instead we store in DB via temporary field? We'll handle in answer handler by recomputing?
        # Better: store shuffled mapping in snapshot copy? We'll just use new_options and track correct
        snap["display_options"]=display_options
        snap["display_correct"]=new_correct
        snap["original_correct"]=correct
    else:
        snap["display_options"]=display_options
        snap["display_correct"]=correct
        snap["original_correct"]=correct

    # save current question pointer in attempt (reuse answered_questions as index)
    attempt.total_questions = len(questions)
    await session.commit()

    await call.message.answer(t.TEST_STARTED.format(current=1, total=len(questions)) + f"\n\n{snap['question_text']}", reply_markup=answer_kb(first.id, display_options, attempt.id))
    await call.answer()

@router.callback_query(F.data.startswith("ans_"))
async def cb_answer(call: CallbackQuery, session, db_user):
    # ans_{attempt_id}_{tq_id}_{selected}
    parts = call.data.split("_")
    attempt_id = int(parts[1])
    tq_id = int(parts[2])
    selected = parts[3]
    attempt = await session.get(TestAttempt, attempt_id)
    if not attempt or attempt.status != AttemptStatus.IN_PROGRESS.value:
        await call.answer("Test yakunlangan", show_alert=True)
        return
    # check duplicate answer
    from sqlalchemy import select
    stmt = select(UserAnswer).where(UserAnswer.attempt_id==attempt_id, UserAnswer.test_question_id==tq_id)
    res = await session.execute(stmt)
    if res.scalar_one_or_none():
        await call.answer("Bu savolga allaqachon javob berdingiz", show_alert=True)
        return
    tq = await session.get(TestQuestion, tq_id)
    snap = tq.snapshot
    # determine correct - use display_correct if exists else correct_option
    # Note: we stored display_correct only in memory not persisted; recompute? For persistence we need to store randomized mapping
    # Simplified: we assume correct_option is still valid after randomization tracking via display_correct in snapshot if present
    # But since we didn't persist shuffled, we fallback to original correct check via value comparison
    display_correct = snap.get("display_correct", snap.get("correct_option"))
    original_correct = snap.get("original_correct", snap.get("correct_option"))
    is_correct = (selected == display_correct) if display_correct else (selected == snap["correct_option"])
    # For accurate tracking, actual_selected is original option that corresponds to selected value
    # Find value of selected display option
    display_options = snap.get("display_options", snap.get("options"))
    selected_value = display_options.get(selected) if display_options else None
    # find original key for that value
    orig_options = snap.get("options")
    actual_selected = None
    if orig_options and selected_value:
        for k,v in orig_options.items():
            if v==selected_value:
                actual_selected=k
                break
    ua = UserAnswer(
        attempt_id=attempt_id,
        test_question_id=tq_id,
        question_id=tq.question_id,
        selected_option=selected,
        actual_selected=actual_selected or selected,
        is_correct=is_correct
    )
    session.add(ua)
    attempt.answered_questions = (attempt.answered_questions or 0) + 1
    if is_correct:
        attempt.correct_answers = (attempt.correct_answers or 0)+1
    else:
        attempt.incorrect_answers = (attempt.incorrect_answers or 0)+1
    await session.commit()
    # feedback
    if is_correct:
        await call.answer("✅ To'g'ri!")
    else:
        await call.answer(f"❌ Noto'g'ri. To'g'ri javob: {display_correct}", show_alert=False)
    # ask next
    await call.message.answer("Keyingi savolga o'tish:", reply_markup=next_question_kb(attempt_id))

@router.callback_query(F.data.startswith("next_"))
async def cb_next(call: CallbackQuery, session, db_user):
    attempt_id = int(call.data.split("_")[1])
    attempt = await session.get(TestAttempt, attempt_id)
    if not attempt:
        await call.answer("Xatolik", show_alert=True)
        return
    from sqlalchemy import select
    stmt = select(TestQuestion).where(TestQuestion.test_id==attempt.test_id).order_by(TestQuestion.order_index)
    res = await session.execute(stmt)
    questions = res.scalars().all()
    # count answered
    stmt2 = select(UserAnswer).where(UserAnswer.attempt_id==attempt_id)
    res2 = await session.execute(stmt2)
    answered = res2.scalars().all()
    answered_tq_ids = {a.test_question_id for a in answered}
    next_q = None
    for q in questions:
        if q.id not in answered_tq_ids:
            next_q = q
            break
    if not next_q:
        # finish
        attempt.status = AttemptStatus.COMPLETED.value
        attempt.completed_at = utcnow()
        if attempt.started_at:
            attempt.duration_seconds = int((attempt.completed_at - attempt.started_at).total_seconds())
        attempt.percentage = (attempt.correct_answers / attempt.total_questions * 100) if attempt.total_questions else 0
        await session.commit()
        duration = format_duration(attempt.duration_seconds)
        txt = t.TEST_COMPLETED.format(correct=attempt.correct_answers, total=attempt.total_questions, incorrect=attempt.incorrect_answers, percent=round(attempt.percentage,1), duration=duration)
        await call.message.answer(txt)
        await call.answer()
        return
    snap = next_q.snapshot
    # randomize answers again if needed
    from app.database.models import Test
    test = await session.get(Test, attempt.test_id)
    display_options = snap.get("options")
    if test.randomize_answers and "display_options" not in snap:
        # create shuffled
        opts = snap["options"]
        correct_val = opts[snap["correct_option"]]
        vals = list(opts.values())
        import random
        random.shuffle(vals)
        new_opts = {}
        new_correct = None
        for i, v in enumerate(vals):
            k = ["A","B","C","D"][i]
            new_opts[k]=v
            if v==correct_val:
                new_correct=k
        snap["display_options"]=new_opts
        snap["display_correct"]=new_correct
        snap["original_correct"]=snap["correct_option"]
        next_q.snapshot = snap
        await session.commit()
        display_options = new_opts
    else:
        display_options = snap.get("display_options", snap.get("options"))
    current = len(answered)+1
    await call.message.answer(f"Savol {current}/{attempt.total_questions}\n\n{snap['question_text']}", reply_markup=answer_kb(next_q.id, display_options, attempt.id))
    await call.answer()
