
from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message
from app.localization.texts import t
from app.database.models import UserRole

router = Router()

@router.message(Command("start"))
async def cmd_start(message: Message, db_user, is_admin: bool):
    name = db_user.first_name or "Xodim"
    text = t.WELCOME.format(name=name)
    if is_admin:
        text += "\n\n" + t.ADMIN_WELCOME + "\n/admin ni bosing."
    else:
        text += "\n\n" + t.WELCOME_EMP
    await message.answer(text)

@router.message(Command("help"))
async def cmd_help(message: Message):
    await message.answer("Buyruqlar:\n/start - boshlash\n/tests - testlar\n/admin - admin panel (faqat adminlar)\n/cancel - bekor qilish")

@router.message(Command("cancel"))
async def cmd_cancel(message: Message, state=None):
    from aiogram.fsm.context import FSMContext
    # state may be injected via filter, but try get
    await message.answer(t.CANCELLED)
