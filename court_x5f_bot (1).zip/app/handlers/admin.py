
from aiogram import Router, F
from aiogram.types import Message, CallbackQuery
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import StatesGroup, State
from sqlalchemy import select, func
from app.keyboards.admin import admin_main_kb, back_kb, materials_kb, tests_kb, employees_kb, confirm_kb
from app.database.models import User, Material, MaterialStatus, News, Test, TestStatus, Question
from app.services.document_processor import process_material
from app.services.test_service import create_test, assign_questions_to_test, publish_test
from app.services.stats_service import get_participation_stats, get_rankings, get_topic_weakness, get_user_stats
from app.services.report_service import generate_excel_report
from app.localization.texts import t
import os, tempfile

router = Router()

class MaterialUpload(StatesGroup):
    waiting_file = State()
    waiting_title = State()

class NewsCreate(StatesGroup):
    title = State()
    body = State()

class TestCreate(StatesGroup):
    title = State()
    num_questions = State()
    duration = State()
    news_percent = State()
    materials = State()

def is_admin_check(is_admin):
    return is_admin

@router.message(Command("admin"))
async def admin_panel(message: Message, is_admin: bool):
    if not is_admin:
        await message.answer(t.NOT_ADMIN)
        return
    await message.answer("👨‍💼 ADMIN PANEL", reply_markup=admin_main_kb())

@router.callback_query(F.data=="admin_main")
async def cb_admin_main(call: CallbackQuery, is_admin: bool):
    if not is_admin:
        await call.answer(t.NOT_ADMIN, show_alert=True)
        return
    await call.message.edit_text("👨‍💼 ADMIN PANEL", reply_markup=admin_main_kb())
    await call.answer()

# Employees
@router.callback_query(F.data=="admin_employees")
async def cb_employees(call: CallbackQuery, session, is_admin: bool):
    if not is_admin:
        await call.answer(t.NOT_ADMIN, show_alert=True); return
    total = (await session.execute(select(func.count(User.id)))).scalar()
    active = (await session.execute(select(func.count(User.id)).where(User.is_active==True))).scalar()
    await call.message.edit_text(f"👥 Xodimlar\n\nJami: {total}\nFaol: {active}", reply_markup=employees_kb())
    await call.answer()

@router.callback_query(F.data.startswith("emp_list_"))
async def cb_emp_list(call: CallbackQuery, session, is_admin: bool):
    if not is_admin:
        await call.answer(t.NOT_ADMIN, show_alert=True); return
    page = int(call.data.split("_")[-1])
    limit=10
    stmt = select(User).order_by(User.id.desc()).limit(limit).offset(page*limit)
    res = await session.execute(stmt)
    users = res.scalars().all()
    text = "👥 Xodimlar ro'yxati\n\n"
    for u in users:
        text+=f"{u.id}. {u.first_name} {u.last_name or ''} - @{u.username or ''} - {u.telegram_id} - {'faol' if u.is_active else 'nofaol'}\n"
    from aiogram.utils.keyboard import InlineKeyboardBuilder
    kb = InlineKeyboardBuilder()
    if page>0:
        kb.button(text="⬅ Oldingi", callback_data=f"emp_list_{page-1}")
    kb.button(text="Keyingi ➡", callback_data=f"emp_list_{page+1}")
    kb.button(text="⬅ Orqaga", callback_data="admin_employees")
    kb.adjust(2,1)
    await call.message.edit_text(text, reply_markup=kb.as_markup())
    await call.answer()

# Materials
@router.callback_query(F.data=="admin_materials")
async def cb_materials(call: CallbackQuery, is_admin: bool):
    if not is_admin: await call.answer(t.NOT_ADMIN, show_alert=True); return
    await call.message.edit_text("📚 Materiallar", reply_markup=materials_kb())
    await call.answer()

@router.callback_query(F.data=="mat_upload")
async def cb_mat_upload(call: CallbackQuery, state: FSMContext, is_admin: bool):
    if not is_admin: await call.answer(t.NOT_ADMIN, show_alert=True); return
    await state.set_state(MaterialUpload.waiting_file)
    await call.message.answer("📄 Fayl yuboring (PDF, DOCX, TXT, MD) yoki matn yuboring.")
    await call.answer()

@router.message(MaterialUpload.waiting_file)
async def handle_file_upload(message: Message, session, state: FSMContext, is_admin: bool):
    if not is_admin:
        await message.answer(t.NOT_ADMIN); return
    title = "Material"
    extracted_text = ""
    file_name = None
    if message.document:
        doc = message.document
        ext = doc.file_name.split(".")[-1].lower() if "." in doc.file_name else ""
        from app.config.settings import settings
        if ext not in settings.allowed_exts:
            await message.answer(f"Ruxsat etilmagan format: {ext}")
            return
        if doc.file_size > settings.MAX_FILE_SIZE_MB*1024*1024:
            await message.answer(f"Fayl juda katta. Maks {settings.MAX_FILE_SIZE_MB} MB")
            return
        # download
        file = await message.bot.get_file(doc.file_id)
        tmp = tempfile.NamedTemporaryFile(delete=False, suffix=f".{ext}")
        await message.bot.download_file(file.file_path, destination=tmp.name)
        tmp.close()
        # extract
        from app.services.document_processor import extract_text_from_file
        text, pages = await extract_text_from_file(tmp.name, ext)
        extracted_text = text
        file_name = doc.file_name
        title = doc.file_name
        os.unlink(tmp.name)
    elif message.text:
        extracted_text = message.text
        file_name = "text_input.txt"
        title = message.text[:50]
    else:
        await message.answer("Fayl yoki matn yuboring")
        return

    mat = Material(title=title, file_name=file_name, category="general", description="", extracted_text=extracted_text, status=MaterialStatus.UPLOADED.value, uploader_id=message.from_user.id)
    session.add(mat)
    await session.commit()
    await session.refresh(mat)
    await message.answer(t.MATERIAL_RECEIVED)
    # process async
    await process_material(session, mat.id)
    mat_after = await session.get(Material, mat.id)
    if mat_after.status == MaterialStatus.READY.value:
        await message.answer(t.MATERIAL_READY.format(title=mat_after.title, chunks=mat_after.chunks_count))
    else:
        await message.answer(t.MATERIAL_FAILED.format(error=mat_after.error_message or "noma'lum"))
    await state.clear()

@router.callback_query(F.data.startswith("mat_list_"))
async def cb_mat_list(call: CallbackQuery, session, is_admin: bool):
    if not is_admin: await call.answer(t.NOT_ADMIN, show_alert=True); return
    page = int(call.data.split("_")[-1])
    limit=10
    stmt = select(Material).order_by(Material.id.desc()).limit(limit).offset(page*limit)
    res = await session.execute(stmt)
    mats = res.scalars().all()
    txt = "📚 Materiallar\n\n"
    for m in mats:
        txt+=f"{m.id}. {m.title} - {m.status} - {m.chunks_count} bo'lak\n"
    from aiogram.utils.keyboard import InlineKeyboardBuilder
    kb = InlineKeyboardBuilder()
    if page>0: kb.button(text="⬅ Oldingi", callback_data=f"mat_list_{page-1}")
    kb.button(text="Keyingi ➡", callback_data=f"mat_list_{page+1}")
    kb.button(text="⬅ Orqaga", callback_data="admin_materials")
    kb.adjust(2,1)
    await call.message.edit_text(txt, reply_markup=kb.as_markup())
    await call.answer()

# News
@router.callback_query(F.data=="admin_news")
async def cb_news(call: CallbackQuery, session, is_admin: bool):
    if not is_admin: await call.answer(t.NOT_ADMIN, show_alert=True); return
    stmt = select(News).order_by(News.id.desc()).limit(10)
    res = await session.execute(stmt)
    news_list = res.scalars().all()
    txt = "📰 Yangiliklar\n\n"
    for n in news_list:
        txt+=f"{n.id}. {n.title} - {'faol' if n.is_active else 'nofaol'}\n"
    from aiogram.utils.keyboard import InlineKeyboardBuilder
    kb = InlineKeyboardBuilder()
    kb.button(text="➕ Qo'shish", callback_data="news_add")
    kb.button(text="⬅ Orqaga", callback_data="admin_main")
    kb.adjust(1,1)
    await call.message.edit_text(txt, reply_markup=kb.as_markup())
    await call.answer()

@router.callback_query(F.data=="news_add")
async def cb_news_add(call: CallbackQuery, state: FSMContext, is_admin: bool):
    if not is_admin: await call.answer(t.NOT_ADMIN, show_alert=True); return
    await state.set_state(NewsCreate.title)
    await call.message.answer("Yangilik sarlavhasini yuboring:")
    await call.answer()

@router.message(NewsCreate.title)
async def news_title(message: Message, state: FSMContext):
    await state.update_data(title=message.text)
    await state.set_state(NewsCreate.body)
    await message.answer("Yangilik matnini yuboring:")

@router.message(NewsCreate.body)
async def news_body(message: Message, session, state: FSMContext):
    data = await state.get_data()
    news = News(title=data['title'], body=message.text, category="general")
    session.add(news)
    await session.commit()
    await state.clear()
    await message.answer(t.NEWS_CREATED)

# Tests
@router.callback_query(F.data=="admin_tests")
async def cb_tests(call: CallbackQuery, is_admin: bool):
    if not is_admin: await call.answer(t.NOT_ADMIN, show_alert=True); return
    await call.message.edit_text("📝 Testlar", reply_markup=tests_kb())
    await call.answer()

@router.callback_query(F.data.startswith("test_list_"))
async def cb_test_list(call: CallbackQuery, session, is_admin: bool):
    if not is_admin: await call.answer(t.NOT_ADMIN, show_alert=True); return
    page = int(call.data.split("_")[-1])
    limit=10
    stmt = select(Test).order_by(Test.id.desc()).limit(limit).offset(page*limit)
    res = await session.execute(stmt)
    tests = res.scalars().all()
    txt = "📝 Testlar\n\n"
    for t in tests:
        txt+=f"{t.id}. {t.title} - {t.status} - {t.num_questions} savol - {t.duration_hours} soat\n"
    from aiogram.utils.keyboard import InlineKeyboardBuilder
    kb = InlineKeyboardBuilder()
    for t in tests:
        kb.button(text=f"Ko'rish {t.id}", callback_data=f"test_view_{t.id}")
    if page>0: kb.button(text="⬅ Oldingi", callback_data=f"test_list_{page-1}")
    kb.button(text="Keyingi ➡", callback_data=f"test_list_{page+1}")
    kb.button(text="⬅ Orqaga", callback_data="admin_tests")
    kb.adjust(2,2,2)
    await call.message.edit_text(txt, reply_markup=kb.as_markup())
    await call.answer()

@router.callback_query(F.data.startswith("test_view_"))
async def cb_test_view(call: CallbackQuery, session, is_admin: bool):
    if not is_admin: await call.answer(t.NOT_ADMIN, show_alert=True); return
    test_id = int(call.data.split("_")[-1])
    test = await session.get(Test, test_id)
    if not test:
        await call.answer("Topilmadi", show_alert=True); return
    stats = await get_participation_stats(session, test_id)
    txt = f"📝 {test.title}\nID: {test.id}\nStatus: {test.status}\nSavollar: {test.num_questions}\nMuddat: {test.duration_hours} soat\nBoshlanish: {test.start_at}\nTugash: {test.deadline_at}\n\nIshtirok: {stats}\n"
    from aiogram.utils.keyboard import InlineKeyboardBuilder
    kb = InlineKeyboardBuilder()
    kb.button(text="✅ Faollashtirish", callback_data=f"test_publish_{test.id}")
    kb.button(text="👥 Ishtirokchilar", callback_data=f"test_part_{test.id}")
    kb.button(text="👀 Savollarni ko'rish", callback_data=f"test_q_{test.id}")
    kb.button(text="📈 Hisobot (Excel)", callback_data=f"test_report_{test.id}")
    kb.button(text="⬅ Orqaga", callback_data="test_list_0")
    kb.adjust(2,2,1)
    await call.message.edit_text(txt, reply_markup=kb.as_markup())
    await call.answer()

@router.callback_query(F.data.startswith("test_publish_"))
async def cb_publish(call: CallbackQuery, session, is_admin: bool):
    if not is_admin: await call.answer(t.NOT_ADMIN, show_alert=True); return
    test_id = int(call.data.split("_")[-1])
    await publish_test(session, test_id)
    await call.answer("Test faollashtirildi ✅")
    await call.message.edit_text(f"Test {test_id} faollashtirildi ✅", reply_markup=back_kb("admin_tests"))

@router.callback_query(F.data.startswith("test_report_"))
async def cb_report(call: CallbackQuery, session, is_admin: bool):
    if not is_admin: await call.answer(t.NOT_ADMIN, show_alert=True); return
    test_id = int(call.data.split("_")[-1])
    await call.answer("Hisobot tayyorlanmoqda...")
    bio = await generate_excel_report(session, test_id)
    from aiogram.types import BufferedInputFile
    await call.message.answer_document(BufferedInputFile(bio.read(), filename=f"test_{test_id}_report.xlsx"), caption="📈 Hisobot")

@router.callback_query(F.data.startswith("test_part_"))
async def cb_part(call: CallbackQuery, session, is_admin: bool):
    if not is_admin: await call.answer(t.NOT_ADMIN, show_alert=True); return
    test_id = int(call.data.split("_")[-1])
    stats = await get_participation_stats(session, test_id)
    txt = f"📊 Ishtirok statistikasi Test {test_id}\n\nJami xodim: {stats['total']}\n✅ Yakunlagan: {stats['completed']}\n🔄 Jarayonda: {stats['in_progress']}\n⏰ Muddati o'tgan: {stats['expired']}\n❌ Qatnashmagan: {stats['not_participated']}\n👥 Jami qatnashgan: {stats['participated']}"
    await call.message.edit_text(txt, reply_markup=back_kb(f"test_view_{test_id}"))
    await call.answer()

@router.callback_query(F.data.startswith("test_q_"))
async def cb_test_q(call: CallbackQuery, session, is_admin: bool):
    if not is_admin: await call.answer(t.NOT_ADMIN, show_alert=True); return
    test_id = int(call.data.split("_")[-1])
    from sqlalchemy import select
    from app.database.models import TestQuestion
    stmt = select(TestQuestion).where(TestQuestion.test_id==test_id).limit(5)
    res = await session.execute(stmt)
    tqs = res.scalars().all()
    txt = f"Test {test_id} savollari (birinchilar)\n\n"
    for tq in tqs:
        snap = tq.snapshot
        txt+=f"Q: {snap['question_text'][:100]}\nA: {snap['correct_option']} - {snap['options'][snap['correct_option']][:50]}\nManba: {snap.get('source_reference','')}\n\n"
    await call.message.edit_text(txt[:4000], reply_markup=back_kb(f"test_view_{test_id}"))
    await call.answer()

@router.callback_query(F.data=="test_create")
async def cb_test_create(call: CallbackQuery, state: FSMContext, is_admin: bool):
    if not is_admin: await call.answer(t.NOT_ADMIN, show_alert=True); return
    await state.set_state(TestCreate.title)
    await call.message.answer("Test nomini yuboring:")
    await call.answer()

@router.message(TestCreate.title)
async def test_title(message: Message, state: FSMContext):
    await state.update_data(title=message.text)
    await state.set_state(TestCreate.num_questions)
    await message.answer("Savollar sonini yuboring (masalan 20):")

@router.message(TestCreate.num_questions)
async def test_num(message: Message, state: FSMContext):
    try:
        num = int(message.text)
    except:
        await message.answer("Iltimos son kiriting")
        return
    await state.update_data(num_questions=num)
    await state.set_state(TestCreate.duration)
    await message.answer("Davomiylik soatlarda (masalan 24):")

@router.message(TestCreate.duration)
async def test_dur(message: Message, state: FSMContext):
    try:
        dur = int(message.text)
    except:
        await message.answer("Son kiriting")
        return
    await state.update_data(duration=dur)
    await state.set_state(TestCreate.news_percent)
    await message.answer("Yangiliklar foizi (0-100, masalan 30):")

@router.message(TestCreate.news_percent)
async def test_news(message: Message, session, state: FSMContext):
    try:
        pct = int(message.text)
    except:
        await message.answer("Son kiriting")
        return
    data = await state.get_data()
    # create test
    test_data = {
        "title": data['title'],
        "num_questions": data['num_questions'],
        "duration_hours": data['duration'],
        "news_percentage": pct,
        "randomize_questions": True,
        "randomize_answers": True,
    }
    test = await create_test(session, test_data, created_by=message.from_user.id)
    await state.clear()
    await message.answer(f"✅ Test yaratildi ID: {test.id}\nSavollar generatsiya qilinmoqda...")
    # assign questions
    from sqlalchemy import select
    stmt = select(Material.id)
    res = await session.execute(stmt)
    mat_ids = res.scalars().all()
    if not mat_ids:
        await message.answer("⚠ Materiallar yo'q, avval material yuklang. Test bo'sh yaratildi.")
        return
    await message.answer(t.QUESTION_GENERATING)
    await assign_questions_to_test(session, test.id, material_ids=mat_ids, news_percentage=pct)
    await message.answer(f"✅ {test.num_questions} ta savol biriktirildi. /admin orqali faollashtiring.")

# Stats
@router.callback_query(F.data=="admin_stats")
async def cb_stats(call: CallbackQuery, session, is_admin: bool):
    if not is_admin: await call.answer(t.NOT_ADMIN, show_alert=True); return
    total_users = (await session.execute(select(func.count(User.id)))).scalar()
    total_tests = (await session.execute(select(func.count(Test.id)))).scalar()
    from app.database.models import TestAttempt, AttemptStatus
    total_attempts = (await session.execute(select(func.count(TestAttempt.id)).where(TestAttempt.status==AttemptStatus.COMPLETED.value))).scalar()
    txt = f"📊 Statistika\n\n👥 Xodimlar: {total_users}\n📝 Testlar: {total_tests}\n✅ Yakunlangan urinishlar: {total_attempts}"
    await call.message.edit_text(txt, reply_markup=back_kb("admin_main"))
    await call.answer()

@router.callback_query(F.data=="admin_ranking")
async def cb_ranking(call: CallbackQuery, session, is_admin: bool):
    if not is_admin: await call.answer(t.NOT_ADMIN, show_alert=True); return
    rankings = await get_rankings(session, 10)
    txt = "🏆 Reyting (Top 10)\n\n"
    for i, (uid, name, avg) in enumerate(rankings,1):
        txt+=f"{i}. {name} - {avg:.1f}%\n"
    await call.message.edit_text(txt, reply_markup=back_kb("admin_main"))
    await call.answer()

@router.callback_query(F.data=="admin_groups")
async def cb_groups(call: CallbackQuery, is_admin: bool):
    if not is_admin: await call.answer(t.NOT_ADMIN, show_alert=True); return
    await call.message.edit_text("👥 Guruhlar\n\nBotni guruhga qo'shing va /register_group buyrug'ini yuboring.", reply_markup=back_kb("admin_main"))
    await call.answer()

@router.callback_query(F.data=="admin_settings")
async def cb_settings(call: CallbackQuery, is_admin: bool):
    if not is_admin: await call.answer(t.NOT_ADMIN, show_alert=True); return
    await call.message.edit_text("⚙ Sozlamalar\n\nTIMEZONE: Asia/Tashkent\nBot versiyasi: 1.0", reply_markup=back_kb("admin_main"))
    await call.answer()

@router.callback_query(F.data=="admin_reports")
async def cb_reports(call: CallbackQuery, is_admin: bool):
    if not is_admin: await call.answer(t.NOT_ADMIN, show_alert=True); return
    await call.message.edit_text("📈 Hisobotlar\n\nTestlar ro'yxatidan hisobot yuklab oling.", reply_markup=back_kb("admin_main"))
    await call.answer()
