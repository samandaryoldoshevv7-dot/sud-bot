
from pydantic_settings import BaseSettings
from typing import List
import os

class Settings(BaseSettings):
    BOT_TOKEN: str
    GROQ_API_KEY: str
    DATABASE_URL: str
    ADMIN_TELEGRAM_IDS: str = ""
    TIMEZONE: str = "Asia/Tashkent"
    EMBEDDING_MODEL: str = "sentence-transformers/all-MiniLM-L6-v2"
    LOG_LEVEL: str = "INFO"
    MAX_FILE_SIZE_MB: int = 20
    ALLOWED_EXTENSIONS: str = "pdf,docx,txt,md"

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"

    @property
    def admin_ids(self) -> List[int]:
        if not self.ADMIN_TELEGRAM_IDS:
            return []
        return [int(x.strip()) for x in self.ADMIN_TELEGRAM_IDS.split(",") if x.strip().isdigit()]

    @property
    def allowed_exts(self) -> List[str]:
        return [e.strip().lower() for e in self.ALLOWED_EXTENSIONS.split(",")]

settings = Settings()
