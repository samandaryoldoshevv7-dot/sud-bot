
from aiogram.utils.keyboard import InlineKeyboardBuilder

def start_test_kb(test_id: int):
    kb = InlineKeyboardBuilder()
    kb.button(text="▶ Testni boshlash", callback_data=f"start_test_{test_id}")
    return kb.as_markup()

def answer_kb(test_question_id: int, options: dict, attempt_id: int):
    kb = InlineKeyboardBuilder()
    # options dict like {"A": "...", "B": "..."} but we need to randomize already handled
    for key in ["A","B","C","D"]:
        if key in options:
            kb.button(text=f"{key}: {options[key][:30]}", callback_data=f"ans_{attempt_id}_{test_question_id}_{key}")
    kb.adjust(1)
    return kb.as_markup()

def next_question_kb(attempt_id: int):
    kb = InlineKeyboardBuilder()
    kb.button(text="Keyingi savol ➡", callback_data=f"next_{attempt_id}")
    return kb.as_markup()
