
from aiogram.utils.keyboard import InlineKeyboardBuilder

def admin_main_kb():
    kb = InlineKeyboardBuilder()
    kb.button(text="👥 Xodimlar", callback_data="admin_employees")
    kb.button(text="📚 Materiallar", callback_data="admin_materials")
    kb.button(text="📰 Yangiliklar", callback_data="admin_news")
    kb.button(text="📝 Testlar", callback_data="admin_tests")
    kb.button(text="📊 Statistika", callback_data="admin_stats")
    kb.button(text="🏆 Reyting", callback_data="admin_ranking")
    kb.button(text="📈 Hisobotlar", callback_data="admin_reports")
    kb.button(text="👥 Guruhlar", callback_data="admin_groups")
    kb.button(text="⚙ Sozlamalar", callback_data="admin_settings")
    kb.adjust(2,2,2,2,1)
    return kb.as_markup()

def back_kb(to="admin_main"):
    kb = InlineKeyboardBuilder()
    kb.button(text="⬅ Orqaga", callback_data=to)
    return kb.as_markup()

def employees_kb(page=0):
    kb = InlineKeyboardBuilder()
    kb.button(text="🔍 Qidirish", callback_data="emp_search")
    kb.button(text="📋 Ro'yxat", callback_data=f"emp_list_{page}")
    kb.button(text="⬅ Orqaga", callback_data="admin_main")
    kb.adjust(1,1,1)
    return kb.as_markup()

def materials_kb():
    kb = InlineKeyboardBuilder()
    kb.button(text="➕ Yuklash", callback_data="mat_upload")
    kb.button(text="📋 Ro'yxat", callback_data="mat_list_0")
    kb.button(text="⬅ Orqaga", callback_data="admin_main")
    kb.adjust(1,1,1)
    return kb.as_markup()

def tests_kb():
    kb = InlineKeyboardBuilder()
    kb.button(text="➕ Yangi test", callback_data="test_create")
    kb.button(text="📋 Ro'yxat", callback_data="test_list_0")
    kb.button(text="⬅ Orqaga", callback_data="admin_main")
    kb.adjust(1,1,1)
    return kb.as_markup()

def confirm_kb(yes="confirm_yes", no="confirm_no"):
    kb = InlineKeyboardBuilder()
    kb.button(text="✅ Ha", callback_data=yes)
    kb.button(text="❌ Yo'q", callback_data=no)
    kb.adjust(2)
    return kb.as_markup()
