
from pydantic import BaseModel, field_validator
from typing import Dict, Optional

class GeneratedQuestion(BaseModel):
    question: str
    options: Dict[str, str]
    correct_answer: str
    explanation: str
    topic: str
    difficulty: str = "medium"
    source_reference: str
    source_excerpt: str

    @field_validator('correct_answer')
    @classmethod
    def validate_correct(cls, v):
        if v not in ['A','B','C','D']:
            raise ValueError('correct_answer must be A,B,C,D')
        return v

    @field_validator('options')
    @classmethod
    def validate_options(cls, v):
        if set(v.keys()) != {'A','B','C','D'}:
            raise ValueError('options must have A,B,C,D')
        for val in v.values():
            if not val or len(val.strip()) < 2:
                raise ValueError('option too short')
        if len(set(v.values())) < 4:
            raise ValueError('duplicate options')
        return v

    @field_validator('question')
    @classmethod
    def validate_q(cls, v):
        if len(v.strip()) < 15:
            raise ValueError('question too short')
        return v
