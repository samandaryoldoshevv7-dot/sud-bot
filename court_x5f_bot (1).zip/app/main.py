
import asyncio, sys
from aiogram import Bot, Dispatcher
from aiogram.fsm.storage.memory import MemoryStorage
from app.config.settings import settings
from app.utils.logger import setup_logging, logger
from app.handlers import common, employee, admin, group
from app.middlewares.auth import AuthMiddleware
from app.database.db import engine
from app.database.models import Base

async def init_db():
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

async def main():
    setup_logging()
    logger.info("Starting bot")
    if not settings.BOT_TOKEN:
        logger.error("BOT_TOKEN missing")
        sys.exit(1)
    try:
        await init_db()
    except Exception as e:
        logger.error(f"DB init failed {e}")
    bot=Bot(token=settings.BOT_TOKEN)
    dp=Dispatcher(storage=MemoryStorage())
    dp.message.middleware(AuthMiddleware())
    dp.callback_query.middleware(AuthMiddleware())
    dp.include_router(common.router)
    dp.include_router(employee.router)
    dp.include_router(admin.router)
    dp.include_router(group.router)

    async def expire_checker():
        from app.database.db import SessionLocal
        from app.database.models import TestAttempt, AttemptStatus
        from sqlalchemy import select
        from datetime import datetime, timezone
        while True:
            try:
                async with SessionLocal() as session:
                    stmt=select(TestAttempt).where(TestAttempt.status==AttemptStatus.IN_PROGRESS.value)
                    res=await session.execute(stmt)
                    attempts=res.scalars().all()
                    now=datetime.now(timezone.utc)
                    for att in attempts:
                        if att.deadline_at:
                            dl=att.deadline_at
                            if dl.tzinfo is None:
                                dl=dl.replace(tzinfo=timezone.utc)
                            if now>dl:
                                att.status=AttemptStatus.EXPIRED.value
                    await session.commit()
            except Exception as e:
                logger.error(f"expire checker {e}")
            await asyncio.sleep(300)
    asyncio.create_task(expire_checker())
    await bot.delete_webhook(drop_pending_updates=True)
    await dp.start_polling(bot)

if __name__=="__main__":
    asyncio.run(main())
