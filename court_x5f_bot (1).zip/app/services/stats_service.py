
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func
from app.database.models import User, TestAttempt, AttemptStatus, Test, UserAnswer, TestQuestion, Question
from datetime import datetime

async def get_participation_stats(session: AsyncSession, test_id: int):
    # total employees
    total_users = (await session.execute(select(func.count(User.id)).where(User.is_active==True))).scalar()
    completed = (await session.execute(select(func.count(TestAttempt.id)).where(TestAttempt.test_id==test_id, TestAttempt.status==AttemptStatus.COMPLETED.value))).scalar()
    in_progress = (await session.execute(select(func.count(TestAttempt.id)).where(TestAttempt.test_id==test_id, TestAttempt.status==AttemptStatus.IN_PROGRESS.value))).scalar()
    expired = (await session.execute(select(func.count(TestAttempt.id)).where(TestAttempt.test_id==test_id, TestAttempt.status==AttemptStatus.EXPIRED.value))).scalar()
    participated_ids = (await session.execute(select(TestAttempt.user_id).where(TestAttempt.test_id==test_id))).scalars().all()
    not_participated = total_users - len(set(participated_ids)) if total_users else 0
    return {
        "total": total_users,
        "completed": completed,
        "in_progress": in_progress,
        "expired": expired,
        "not_participated": not_participated,
        "participated": len(set(participated_ids))
    }

async def get_user_stats(session: AsyncSession, user_id: int):
    stmt = select(TestAttempt).where(TestAttempt.user_id==user_id, TestAttempt.status==AttemptStatus.COMPLETED.value)
    res = await session.execute(stmt)
    attempts = res.scalars().all()
    if not attempts:
        return {"total":0, "avg":0, "best":0, "worst":0}
    scores = [a.percentage for a in attempts]
    return {
        "total": len(attempts),
        "avg": sum(scores)/len(scores),
        "best": max(scores),
        "worst": min(scores),
        "completed": len(attempts)
    }

async def get_topic_weakness(session: AsyncSession, user_id: int):
    # join user_answers -> test_question snapshot topic
    stmt = select(UserAnswer, TestQuestion).join(TestQuestion, UserAnswer.test_question_id==TestQuestion.id).join(TestAttempt, UserAnswer.attempt_id==TestAttempt.id).where(TestAttempt.user_id==user_id)
    res = await session.execute(stmt)
    rows = res.all()
    from collections import defaultdict
    topic_stats = defaultdict(lambda: {"total":0, "correct":0})
    for ua, tq in rows:
        topic = tq.snapshot.get('topic','general')
        topic_stats[topic]["total"]+=1
        if ua.is_correct:
            topic_stats[topic]["correct"]+=1
    result = []
    for topic, data in topic_stats.items():
        if data["total"]>0:
            acc = data["correct"]/data["total"]*100
            result.append({"topic":topic, "accuracy":acc, "total":data["total"]})
    result.sort(key=lambda x: x["accuracy"])
    return result

async def get_rankings(session: AsyncSession, limit=10):
    stmt = select(User.id, User.first_name, func.avg(TestAttempt.percentage).label('avg_score')).join(TestAttempt, TestAttempt.user_id==User.id).where(TestAttempt.status==AttemptStatus.COMPLETED.value).group_by(User.id).order_by(func.avg(TestAttempt.percentage).desc()).limit(limit)
    res = await session.execute(stmt)
    return res.all()
