
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func
from app.database.models import Question, Material
from app.ai.groq_client import provider
from app.ai.validator import validate_question
from app.services.rag_service import get_random_chunks
try:
    try:
    import logging
    _slog=True
except:
    _slog=False
    import logging as structlog

    except:
    import logging as _lg
    logger = _lg.getLogger(__name__)


async def generate_questions_for_materials(session: AsyncSession, material_ids, num_questions: int, topic: str = "general"):
    chunks = await get_random_chunks(session, material_ids, limit=num_questions*3)
    generated = []
    raw = await provider.generate_questions_batch(chunks, num_questions, topic=topic)
    for item in raw:
        valid, result = validate_question(item)
        if not valid:
            continue
        q = Question(
            question_text=result.question,
            option_a=result.options['A'],
            option_b=result.options['B'],
            option_c=result.options['C'],
            option_d=result.options['D'],
            correct_option=result.correct_answer,
            explanation=result.explanation,
            topic=result.topic,
            difficulty=result.difficulty,
            source_document_id=chunks[0].material_id if chunks else None,
            source_chunk_id=item.get('_source_chunk_id'),
            source_reference=result.source_reference,
            source_excerpt=result.source_excerpt[:500],
            ai_metadata={"model": provider.model}
        )
        session.add(q)
        generated.append(q)
    await session.commit()
    return generated

async def get_question_bank(session: AsyncSession, topic=None, difficulty=None, search=None, limit=20, offset=0):
    stmt = select(Question).where(Question.is_approved==True)
    if topic:
        stmt = stmt.where(Question.topic.ilike(f"%{topic}%"))
    if difficulty and difficulty!='mixed':
        stmt = stmt.where(Question.difficulty==difficulty)
    if search:
        stmt = stmt.where(Question.question_text.ilike(f"%{search}%"))
    stmt = stmt.order_by(Question.id.desc()).limit(limit).offset(offset)
    res = await session.execute(stmt)
    return res.scalars().all()
