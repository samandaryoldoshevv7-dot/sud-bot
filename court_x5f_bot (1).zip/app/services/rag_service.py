
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.database.models import MaterialChunk, Material
from app.rag.embeddings import embed_texts, cosine_similarity
from typing import List

async def retrieve_relevant_chunks(session: AsyncSession, query: str, material_ids: List[int] = None, top_k: int = 5):
    # embed query
    q_emb = embed_texts([query])[0]
    stmt = select(MaterialChunk)
    if material_ids:
        stmt = stmt.where(MaterialChunk.material_id.in_(material_ids))
    result = await session.execute(stmt)
    chunks = result.scalars().all()
    # score
    scored = []
    for ch in chunks:
        if not ch.embedding:
            continue
        score = cosine_similarity(q_emb, ch.embedding)
        scored.append((score, ch))
    scored.sort(key=lambda x: x[0], reverse=True)
    return [c for s,c in scored[:top_k]]

async def get_random_chunks(session: AsyncSession, material_ids: List[int], limit: int = 10):
    stmt = select(MaterialChunk).where(MaterialChunk.material_id.in_(material_ids)).order_by(MaterialChunk.id)
    result = await session.execute(stmt)
    all_chunks = result.scalars().all()
    import random
    random.shuffle(all_chunks)
    return all_chunks[:limit]
