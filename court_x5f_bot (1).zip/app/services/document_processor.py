
import os, tempfile
from PyPDF2 import PdfReader
from docx import Document
from app.rag.chunker import chunk_text
from app.database.models import Material, MaterialChunk, MaterialStatus
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
try:
    try:
    import logging
    _slog=True
except:
    _slog=False
    import logging as structlog

    except:
    import logging as _lg
    logger = _lg.getLogger(__name__)
, aiofiles

async def extract_text_from_file(file_path: str, ext: str):
    ext = ext.lower()
    if ext == 'pdf':
        reader = PdfReader(file_path)
        pages = []
        full = ""
        for i, page in enumerate(reader.pages):
            try:
                t = page.extract_text() or ""
                pages.append((i+1, t))
                full += f"\n\n--- Page {i+1} ---\n\n" + t
            except Exception as e:
                logger.error("pdf page error", error=str(e))
        return full, pages
    elif ext == 'docx':
        doc = Document(file_path)
        text = "\n".join([p.text for p in doc.paragraphs])
        return text, [(1, text)]
    else:  # txt, md
        async with aiofiles.open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
            content = await f.read()
        return content, [(1, content)]

async def process_material(session: AsyncSession, material_id: int):
    material = await session.get(Material, material_id)
    if not material:
        return
    material.status = MaterialStatus.PROCESSING.value
    await session.commit()
    try:
        # we need to find file - we stored file_path in description? Let's store temp download path handling elsewhere
        # Here material.extracted_text already maybe set, but if file_id, we need download done before
        text = material.extracted_text or ""
        if not text and material.file_name:
            # fallback: if file path passed in file_name as local path (for testing)
            if os.path.exists(material.file_name):
                txt, pages = await extract_text_from_file(material.file_name, material.file_name.split('.')[-1])
                text = txt
            else:
                raise ValueError("No text and file not found")
        # chunk
        from app.rag.embeddings import embed_texts
        chunks = chunk_text(text, 800, 100)
        embeddings = embed_texts(chunks)
        # clear old chunks
        await session.execute(select(MaterialChunk).where(MaterialChunk.material_id==material_id))
        # delete
        from sqlalchemy import delete
        await session.execute(delete(MaterialChunk).where(MaterialChunk.material_id==material_id))
        for idx, (ch, emb) in enumerate(zip(chunks, embeddings)):
            mc = MaterialChunk(material_id=material_id, chunk_index=idx, text=ch, embedding=emb, page_number=None)
            session.add(mc)
        material.chunks_count = len(chunks)
        material.extracted_text = text[:50000]  # store truncated for display
        material.status = MaterialStatus.READY.value
        await session.commit()
        logger.info("material processed", id=material_id, chunks=len(chunks))
    except Exception as e:
        logger.error("material processing failed", error=str(e), id=material_id)
        material.status = MaterialStatus.FAILED.value
        material.error_message = str(e)[:1000]
        await session.commit()
