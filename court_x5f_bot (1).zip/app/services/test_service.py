
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, delete
from app.database.models import Test, Question, TestQuestion, TestStatus, TestAttempt, AttemptStatus, User
import random, json
from datetime import datetime, timedelta, timezone
from app.utils.time import utcnow

async def create_test(session: AsyncSession, data: dict, created_by: int):
    test = Test(
        title=data['title'],
        description=data.get('description',''),
        num_questions=data.get('num_questions',20),
        news_percentage=data.get('news_percentage',0),
        duration_hours=data.get('duration_hours',24),
        randomize_questions=data.get('randomize_questions',True),
        randomize_answers=data.get('randomize_answers',True),
        passing_percentage=data.get('passing_percentage',70),
        allow_retake=data.get('allow_retake',False),
        show_correct_after=data.get('show_correct_after',False),
        difficulty=data.get('difficulty','mixed'),
        status=TestStatus.DRAFT.value,
        created_by=created_by,
        start_at=utcnow(),
        deadline_at=utcnow()+timedelta(hours=data.get('duration_hours',24))
    )
    session.add(test)
    await session.commit()
    await session.refresh(test)
    return test

async def assign_questions_to_test(session: AsyncSession, test_id: int, material_ids=None, news_percentage=0):
    test = await session.get(Test, test_id)
    if not test:
        return None
    # clear existing
    await session.execute(delete(TestQuestion).where(TestQuestion.test_id==test_id))
    # select questions
    # simple: get approved questions
    stmt = select(Question).where(Question.is_approved==True)
    if material_ids:
        stmt = stmt.where(Question.source_document_id.in_(material_ids))
    # news handling simplified: if news_percentage >0, try include news-related? We treat all questions same for MVP but respect percentage by topic
    result = await session.execute(stmt.order_by(Question.id.desc()).limit(test.num_questions*3))
    questions = result.scalars().all()
    if len(questions) < test.num_questions:
        # need to generate more
        from app.services.question_service import generate_questions_for_materials
        if material_ids:
            await generate_questions_for_materials(session, material_ids, test.num_questions - len(questions))
            result = await session.execute(stmt.order_by(Question.id.desc()).limit(test.num_questions*3))
            questions = result.scalars().all()
    random.shuffle(questions)
    selected = questions[:test.num_questions]
    # avoid duplicates
    seen = set()
    final = []
    for q in selected:
        if q.id in seen:
            continue
        seen.add(q.id)
        final.append(q)
    # create test_questions with snapshot
    for idx, q in enumerate(final):
        snapshot = {
            "question_text": q.question_text,
            "options": {"A": q.option_a, "B": q.option_b, "C": q.option_c, "D": q.option_d},
            "correct_option": q.correct_option,
            "explanation": q.explanation,
            "topic": q.topic,
            "difficulty": q.difficulty,
            "source_reference": q.source_reference,
            "source_excerpt": q.source_excerpt,
        }
        tq = TestQuestion(test_id=test_id, question_id=q.id, order_index=idx, snapshot=snapshot)
        session.add(tq)
    test.status = TestStatus.READY.value
    await session.commit()
    return test

async def publish_test(session: AsyncSession, test_id: int):
    test = await session.get(Test, test_id)
    if not test:
        return None
    test.status = TestStatus.ACTIVE.value
    test.start_at = utcnow()
    test.deadline_at = utcnow()+timedelta(hours=test.duration_hours)
    await session.commit()
    return test

async def start_attempt(session: AsyncSession, test_id: int, user_id: int, telegram_id: int):
    # check existing in progress
    stmt = select(TestAttempt).where(TestAttempt.test_id==test_id, TestAttempt.user_id==user_id, TestAttempt.status==AttemptStatus.IN_PROGRESS.value)
    res = await session.execute(stmt)
    existing = res.scalar_one_or_none()
    if existing:
        return existing
    # check completed and no retake
    test = await session.get(Test, test_id)
    if not test:
        return None
    if not test.allow_retake:
        stmt2 = select(TestAttempt).where(TestAttempt.test_id==test_id, TestAttempt.user_id==user_id, TestAttempt.status==AttemptStatus.COMPLETED.value)
        res2 = await session.execute(stmt2)
        if res2.scalar_one_or_none():
            return None
    attempt = TestAttempt(
        test_id=test_id,
        user_id=user_id,
        telegram_id=telegram_id,
        status=AttemptStatus.IN_PROGRESS.value,
        started_at=utcnow(),
        deadline_at=test.deadline_at,
        total_questions=test.num_questions
    )
    session.add(attempt)
    await session.commit()
    await session.refresh(attempt)
    return attempt

async def get_test_questions_for_attempt(session: AsyncSession, test_id: int):
    stmt = select(TestQuestion).where(TestQuestion.test_id==test_id).order_by(TestQuestion.order_index)
    res = await session.execute(stmt)
    return res.scalars().all()
