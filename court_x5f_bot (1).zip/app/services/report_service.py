
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.database.models import TestAttempt, User, Test
import io, openpyxl
from openpyxl.styles import Font

async def generate_excel_report(session: AsyncSession, test_id: int):
    test = await session.get(Test, test_id)
    stmt = select(TestAttempt, User).join(User, TestAttempt.user_id==User.id).where(TestAttempt.test_id==test_id)
    res = await session.execute(stmt)
    rows = res.all()
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Natijalar"
    headers = ["Xodim", "Telegram ID", "Test", "Boshlangan", "Yakunlangan", "Davomiylik (son)", "Jami savol", "Javob berilgan", "To'g'ri", "Noto'g'ri", "Foiz", "Status"]
    ws.append(headers)
    for cell in ws[1]:
        cell.font = Font(bold=True)
    for attempt, user in rows:
        ws.append([
            f"{user.first_name} {user.last_name or ''}".strip(),
            user.telegram_id,
            test.title if test else "",
            str(attempt.started_at),
            str(attempt.completed_at),
            attempt.duration_seconds,
            attempt.total_questions,
            attempt.answered_questions,
            attempt.correct_answers,
            attempt.incorrect_answers,
            attempt.percentage,
            attempt.status
        ])
    # summary sheet
    ws2 = wb.create_sheet("Xodimlar xulosasi")
    ws2.append(["Xodim", "Testlar", "O'rtacha ball", "Eng yaxshi", "Eng yomon"])
    # simple
    from app.services.stats_service import get_rankings
    # ...
    bio = io.BytesIO()
    wb.save(bio)
    bio.seek(0)
    return bio
