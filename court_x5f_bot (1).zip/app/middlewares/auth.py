
from aiogram import BaseMiddleware
from typing import Callable, Dict, Any, Awaitable
from aiogram.types import Message
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.database.models import User, UserRole
from app.config.settings import settings
from app.database.db import SessionLocal

class AuthMiddleware(BaseMiddleware):
    async def __call__(self, handler: Callable[[Message, Dict[str, Any]], Awaitable[Any]], event: Message, data: Dict[str, Any]) -> Any:
        # ensure user exists
        tg_user = event.from_user
        if not tg_user:
            return await handler(event, data)
        async with SessionLocal() as session:
            stmt = select(User).where(User.telegram_id==tg_user.id)
            res = await session.execute(stmt)
            user = res.scalar_one_or_none()
            if not user:
                role = UserRole.ADMIN.value if tg_user.id in settings.admin_ids else UserRole.EMPLOYEE.value
                user = User(
                    telegram_id=tg_user.id,
                    username=tg_user.username,
                    first_name=tg_user.first_name,
                    last_name=tg_user.last_name,
                    role=role,
                    is_active=True
                )
                session.add(user)
                await session.commit()
                await session.refresh(user)
            else:
                # update last active and username
                user.username = tg_user.username
                user.first_name = tg_user.first_name
                user.last_name = tg_user.last_name
                await session.commit()
            data['db_user'] = user
            data['is_admin'] = user.role == UserRole.ADMIN.value or tg_user.id in settings.admin_ids
            data['session'] = session
            # we keep session open for handler; close after
            try:
                return await handler(event, data)
            finally:
                await session.close()
