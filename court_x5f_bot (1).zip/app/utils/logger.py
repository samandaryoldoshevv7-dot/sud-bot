
import logging
from app.config.settings import settings
def setup_logging():
    logging.basicConfig(level=getattr(logging, settings.LOG_LEVEL.upper(), logging.INFO))
    return logging.getLogger("court_bot")
logger = logging.getLogger("court_bot")
