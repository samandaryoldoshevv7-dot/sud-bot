
from datetime import datetime, timezone
import pytz
from app.config.settings import settings

def utcnow():
    return datetime.now(timezone.utc)

def to_tashkent(dt):
    if dt is None:
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    tz = pytz.timezone(settings.TIMEZONE)
    return dt.astimezone(tz)

def format_duration(seconds: int) -> str:
    m, s = divmod(seconds, 60)
    h, m = divmod(m, 60)
    if h:
        return f"{h} soat {m} daq {s} son"
    return f"{m} daq {s} son"
