
from sqlalchemy import Column, Integer, BigInteger, String, Text, Boolean, DateTime, ForeignKey, Float, Enum, Index, JSON
from sqlalchemy.orm import declarative_base, relationship
from sqlalchemy.dialects.postgresql import JSONB
from datetime import datetime
import enum

Base = declarative_base()

class UserRole(str, enum.Enum):
    ADMIN = "ADMIN"
    EMPLOYEE = "EMPLOYEE"

class MaterialStatus(str, enum.Enum):
    UPLOADED = "UPLOADED"
    PROCESSING = "PROCESSING"
    READY = "READY"
    FAILED = "FAILED"

class TestStatus(str, enum.Enum):
    DRAFT = "DRAFT"
    READY = "READY"
    ACTIVE = "ACTIVE"
    EXPIRED = "EXPIRED"
    CLOSED = "CLOSED"

class AttemptStatus(str, enum.Enum):
    NOT_STARTED = "NOT_STARTED"
    IN_PROGRESS = "IN_PROGRESS"
    COMPLETED = "COMPLETED"
    EXPIRED = "EXPIRED"
    CANCELLED = "CANCELLED"

class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True)
    telegram_id = Column(BigInteger, unique=True, index=True, nullable=False)
    username = Column(String(255), nullable=True)
    first_name = Column(String(255))
    last_name = Column(String(255))
    role = Column(String(20), default=UserRole.EMPLOYEE.value)
    is_active = Column(Boolean, default=True)
    group_id = Column(Integer, ForeignKey("groups.id"), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    last_active = Column(DateTime, default=datetime.utcnow)

class Group(Base):
    __tablename__ = "groups"
    id = Column(Integer, primary_key=True)
    telegram_group_id = Column(BigInteger, unique=True)
    title = Column(String(500))
    is_authorized = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)

class Material(Base):
    __tablename__ = "materials"
    id = Column(Integer, primary_key=True)
    title = Column(String(500), nullable=False)
    file_name = Column(String(500))
    file_id = Column(String(500))
    category = Column(String(200), default="general")
    description = Column(Text)
    status = Column(String(20), default=MaterialStatus.UPLOADED.value)
    error_message = Column(Text)
    extracted_text = Column(Text)
    uploader_id = Column(BigInteger)
    created_at = Column(DateTime, default=datetime.utcnow)
    chunks_count = Column(Integer, default=0)

class MaterialChunk(Base):
    __tablename__ = "material_chunks"
    id = Column(Integer, primary_key=True)
    material_id = Column(Integer, ForeignKey("materials.id", ondelete="CASCADE"), index=True)
    chunk_index = Column(Integer)
    page_number = Column(Integer, nullable=True)
    text = Column(Text, nullable=False)
    embedding = Column(JSON, nullable=True)  # store as JSON list for portability, pgvector optional
    created_at = Column(DateTime, default=datetime.utcnow)
    material = relationship("Material", backref="chunks")

class News(Base):
    __tablename__ = "news"
    id = Column(Integer, primary_key=True)
    title = Column(String(500), nullable=False)
    body = Column(Text, nullable=False)
    category = Column(String(200), default="general")
    source = Column(String(500))
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)

class Question(Base):
    __tablename__ = "questions"
    id = Column(Integer, primary_key=True)
    question_text = Column(Text, nullable=False)
    option_a = Column(Text, nullable=False)
    option_b = Column(Text, nullable=False)
    option_c = Column(Text, nullable=False)
    option_d = Column(Text, nullable=False)
    correct_option = Column(String(1), nullable=False)  # A,B,C,D
    explanation = Column(Text)
    topic = Column(String(300))
    difficulty = Column(String(20), default="medium")
    source_document_id = Column(Integer, ForeignKey("materials.id"), nullable=True)
    source_chunk_id = Column(Integer, ForeignKey("material_chunks.id"), nullable=True)
    source_reference = Column(String(500))
    source_excerpt = Column(Text)
    is_approved = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    ai_metadata = Column(JSON, nullable=True)

class Test(Base):
    __tablename__ = "tests"
    id = Column(Integer, primary_key=True)
    title = Column(String(500), nullable=False)
    description = Column(Text)
    num_questions = Column(Integer, default=20)
    num_options = Column(Integer, default=4)
    difficulty = Column(String(20), default="mixed")
    news_percentage = Column(Integer, default=0)
    duration_hours = Column(Integer, default=24)
    randomize_questions = Column(Boolean, default=True)
    randomize_answers = Column(Boolean, default=True)
    show_correct_after = Column(Boolean, default=False)  # False = after completion
    allow_retake = Column(Boolean, default=False)
    passing_percentage = Column(Integer, default=70)
    status = Column(String(20), default=TestStatus.DRAFT.value)
    start_at = Column(DateTime, nullable=True)
    deadline_at = Column(DateTime, nullable=True)
    created_by = Column(BigInteger)
    created_at = Column(DateTime, default=datetime.utcnow)

class TestQuestion(Base):
    __tablename__ = "test_questions"
    id = Column(Integer, primary_key=True)
    test_id = Column(Integer, ForeignKey("tests.id", ondelete="CASCADE"), index=True)
    question_id = Column(Integer, ForeignKey("questions.id", ondelete="CASCADE"))
    order_index = Column(Integer)
    # snapshot to keep result reproducible
    snapshot = Column(JSON, nullable=False)
    test = relationship("Test", backref="test_questions")
    question = relationship("Question")

class TestAttempt(Base):
    __tablename__ = "test_attempts"
    id = Column(Integer, primary_key=True)
    test_id = Column(Integer, ForeignKey("tests.id"), index=True)
    user_id = Column(Integer, ForeignKey("users.id"), index=True)
    telegram_id = Column(BigInteger, index=True)
    status = Column(String(20), default=AttemptStatus.NOT_STARTED.value)
    started_at = Column(DateTime, nullable=True)
    completed_at = Column(DateTime, nullable=True)
    deadline_at = Column(DateTime, nullable=True)
    total_questions = Column(Integer, default=0)
    answered_questions = Column(Integer, default=0)
    correct_answers = Column(Integer, default=0)
    incorrect_answers = Column(Integer, default=0)
    score = Column(Float, default=0.0)
    percentage = Column(Float, default=0.0)
    duration_seconds = Column(Integer, default=0)

class UserAnswer(Base):
    __tablename__ = "user_answers"
    id = Column(Integer, primary_key=True)
    attempt_id = Column(Integer, ForeignKey("test_attempts.id", ondelete="CASCADE"), index=True)
    test_question_id = Column(Integer, ForeignKey("test_questions.id"))
    question_id = Column(Integer, ForeignKey("questions.id"))
    selected_option = Column(String(1), nullable=True)  # A,B,C,D as displayed (mapped)
    actual_selected = Column(String(1), nullable=True)  # original A-D before randomization
    is_correct = Column(Boolean, default=False)
    answered_at = Column(DateTime, default=datetime.utcnow)
